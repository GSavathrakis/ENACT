# ENACT
Entropy-based Attention Clustering Tranformer
